// Base lists of bad domains
const regularDomains = ["doubleclick.net", "googleadservices.com", "://googlesyndication.com"];
const superDomains = [...regularDomains, "://google.com", "scorecardresearch.com", "adnxs.com", "amazon-adsystem.com"];

async function updateAdBlockerRules() {
  // 1. Fetch current settings from memory
  const data = await chrome.storage.local.get(['blockingMode', 'excludedWebsites']);
  const mode = data.blockingMode || 'regular';
  const whitelist = data.excludedWebsites || [];

  // 2. Clear out all existing rules
  const oldRules = await chrome.declarativeNetRequest.getDynamicRules();
  const oldIds = oldRules.map(rule => rule.id);
  
  // 3. Choose which domain list to apply
  const targetDomains = (mode === 'super') ? superDomains : regularDomains;
  const newRules = [];
  let ruleId = 1;

  // 4. Build tracking rules for domains, keeping exclusions in mind
  targetDomains.forEach(domain => {
    newRules.push({
      id: ruleId++,
      priority: 1,
      action: { type: "block" },
      condition: {
        urlFilter: `||${domain}`,
        // This line tells Chrome NOT to apply the blocking rule on whitelisted domains
        excludedInitiatorDomains: whitelist, 
        resourceTypes: ["script", "sub_frame", "xmlhttprequest", "image"]
      }
    });
  });

  // 5. Apply the freshly generated rules directly to Chrome's firewall engine
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldIds,
    addRules: newRules
  });
}

// Update rules immediately upon browser installation or menu changes
chrome.runtime.onInstalled.addListener(updateAdBlockerRules);
chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "updateRules") {
    updateAdBlockerRules();
  }
});
