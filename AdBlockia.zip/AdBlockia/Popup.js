document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById('saveBtn');
  const whitelistInput = document.getElementById('whitelist');
  const themeSelect = document.getElementById('themeSelect');

  // Load previously saved settings
  chrome.storage.local.get(['blockingMode', 'excludedWebsites', 'uiTheme'], (data) => {
    if (data.blockingMode) {
      const radio = document.querySelector(`input[name="mode"][value="${data.blockingMode}"]`);
      if (radio) radio.checked = true;
    }
    if (data.excludedWebsites) {
      whitelistInput.value = data.excludedWebsites.join('\n');
    }
    if (data.uiTheme) {
      themeSelect.value = data.uiTheme;
      document.documentElement.setAttribute('data-theme', data.uiTheme);
    } else {
      // Default to system settings if nothing has been saved yet
      themeSelect.value = 'system';
      document.documentElement.setAttribute('data-theme', 'system');
    }
  });

  // Preview theme changes dynamically when the user flips the dropdown menu
  themeSelect.addEventListener('change', () => {
    document.documentElement.setAttribute('data-theme', themeSelect.value);
  });

  // Save all configurations together
  saveBtn.addEventListener('click', () => {
    const selectedMode = document.querySelector('input[name="mode"]:checked').value;
    const lines = whitelistInput.value.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    const chosenTheme = themeSelect.value;

    chrome.storage.local.set({
      blockingMode: selectedMode,
      excludedWebsites: lines,
      uiTheme: chosenTheme
    }, () => {
      chrome.runtime.sendMessage({ action: "updateRules" });
      alert('Settings saved successfully!');
    });
  });
});
